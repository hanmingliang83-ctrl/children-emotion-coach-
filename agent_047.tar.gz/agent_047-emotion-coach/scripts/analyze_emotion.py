#!/usr/bin/env python3
"""#47 情绪分析工具"""
import sys, json

EMOTIONS = {
    "愤怒": {"key": ["生气","愤怒","发火","烦躁","恼火"], "category": "负面"},
    "悲伤": {"key": ["难过","伤心","悲伤","沮丧","失落"], "category": "负面"},
    "恐惧": {"key": ["害怕","恐惧","紧张","担心","不安"], "category": "负面"},
    "焦虑": {"key": ["焦虑","烦躁","担心","不安","紧张"], "category": "负面"},
    "快乐": {"key": ["开心","快乐","高兴","愉快","兴奋"], "category": "正面"},
}

def analyze(text: str, age: int = None) -> dict:
    scores = {e: sum(1 for k in info["key"] if k in text) for e, info in EMOTIONS.items()}
    primary = max(scores, key=scores.get) if max(scores.values()) > 0 else "未识别"
    age_group = "0-3岁" if age and age < 3 else "3-6岁" if age and age < 6 else "6-9岁" if age and age < 9 else "9-12岁" if age and age < 12 else "12-15岁"
    return {"emotion": primary, "confidence": scores[primary] / 3, "age_group": age_group}

if __name__ == "__main__":
    text = sys.argv[1] if len(sys.argv) > 1 else "孩子很生气"
    age = int(sys.argv[2]) if len(sys.argv) > 2 else None
    print(json.dumps(analyze(text, age), ensure_ascii=False))
